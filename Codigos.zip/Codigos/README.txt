Orden de importancia de los archivos:

CShtml.txt
p5.min.js ¡Innecesario en el editor oline! /*Funciones de P5*/
indexjs.txt
Linejs.txt
robotjs.txt
simpleLinejs.txt
boxesjs.text
realboxjs.text
randomTree.js
anaquel.js
completeLinesjs.text ¡Intento de optimizar el dibujado(fallido)!